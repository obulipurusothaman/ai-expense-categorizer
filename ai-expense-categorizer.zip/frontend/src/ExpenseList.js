import React, { useEffect, useState } from "react";
import axios from "axios";

export default function ExpenseList() {
  const [data,setData]=useState([]);

  useEffect(()=>{
    axios.get("http://localhost:8080/api/expenses")
    .then(res=>setData(res.data));
  },[]);

  return (
    <div>
      {data.map(e=>(
        <div key={e.id}>
          {e.description} - {e.amount} - {e.category}
        </div>
      ))}
    </div>
  );
}