import React from "react";
import ExpenseForm from "./ExpenseForm";
import ExpenseList from "./ExpenseList";

function App() {
  return (
    <div>
      <h2>AI Expense Categorizer</h2>
      <ExpenseForm />
      <ExpenseList />
    </div>
  );
}
export default App;