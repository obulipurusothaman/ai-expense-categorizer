import React, { useState } from "react";
import axios from "axios";

export default function ExpenseForm() {
  const [desc, setDesc] = useState("");
  const [amt, setAmt] = useState("");

  const submit = async () => {
    await axios.post("http://localhost:8080/api/expenses", {
      description: desc,
      amount: amt
    });
    alert("Added");
  };

  return (
    <div>
      <input onChange={e=>setDesc(e.target.value)} placeholder="desc"/>
      <input onChange={e=>setAmt(e.target.value)} placeholder="amount"/>
      <button onClick={submit}>Add</button>
    </div>
  );
}