package com.example.expense.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import com.example.expense.model.Expense;
import com.example.expense.repository.ExpenseRepository;
import com.example.expense.util.ExpenseClassifier;

@Service
public class ExpenseService {
    @Autowired private ExpenseRepository repo;
    @Autowired private ExpenseClassifier classifier;

    public Expense save(Expense e) {
        e.setCategory(classifier.classify(e.getDescription()));
        e.setCreatedAt(LocalDateTime.now());
        return repo.save(e);
    }

    public List<Expense> getAll() {
        return repo.findAll();
    }
}