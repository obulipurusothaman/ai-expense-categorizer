package com.example.expense.util;
import org.springframework.stereotype.Component;

@Component
public class ExpenseClassifier {
    public String classify(String text) {
        text = text.toLowerCase();
        if (text.contains("swiggy") || text.contains("zomato")) return "Food";
        if (text.contains("uber") || text.contains("ola")) return "Travel";
        if (text.contains("bill") || text.contains("rent")) return "Bills";
        return "Others";
    }
}