package com.example.expense.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import com.example.expense.model.Expense;
import com.example.expense.service.ExpenseService;

@RestController
@RequestMapping("/api/expenses")
@CrossOrigin
public class ExpenseController {
    @Autowired private ExpenseService service;

    @PostMapping
    public Expense add(@RequestBody Expense e) {
        return service.save(e);
    }

    @GetMapping
    public List<Expense> getAll() {
        return service.getAll();
    }
}